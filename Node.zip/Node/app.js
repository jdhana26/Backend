import { add } from "./add.js";

const result = add(10, 5);
console.log("Sum =", result);